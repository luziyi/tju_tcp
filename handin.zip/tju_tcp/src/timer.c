#include "timer.h"

void initTimer(tju_tcp_t *sock)
{
    struct timeval nowtime;
    while (1)
    {
    }
}

void sendwithretransmit(tju_tcp_t *sock, char *package_buf, int package_len)
{
    gettimeofday(&nowtime, NULL);
}