#ifndef TIMER_H
#define TIMER_H

#include <sys/time.h>
#include <stdio.h>
#include "global.h"
#include "timer.h"

void initTimer(tju_tcp_t* sock);

#endif
