#ifndef TIME_H
#define TIME_H

#include <pthread.h>
#include <sys/time.h>
#include "tju_tcp.h"
#include "time_helper.h"
#include "global.h"


void timer_start(void *arg);


#endif
